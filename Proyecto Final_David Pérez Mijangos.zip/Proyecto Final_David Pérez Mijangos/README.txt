# Proyecto Final: Descubriendo CDMX
# David Pérez Mijangos

Libreta de jupyter con el desarrollo de una pequeña aplicación en forma de función para encontrar los espacios
culturales más cercanos a un punto dado por coordenadas geográficas en la CDMX.

## Índice

- [Instalación]
- [Uso]
- [Contribución]
- [Fuentes de datos]

## Instalación

Ejecutar en un entorno de Python 3.10 o posterior e instalar las siguientes librerías usando pip

libpysal, numpy, geopandas, pandas, networkx, matplotlib, requests, json, geopy

Una vez hecho eso, ejecutar la libreta de jupyter "MadiProyecto.ipynb".

## Uso

El uso es intuitivo y se explican con detalle en la libreta, leer los comentarios y la documentación
de la función final.

## Contribución

Se anima a convetir el código en una clase para su posterior utilización en aplicaciones de usuario con un entorno
gráfico más amigable y prático. También se propone incrementar los datos de los espacios culturales incluyendo
los horarios y el costo de cada uno para incluir restricciones de presupuesto y tiempo.

## Fuentes de datos

- Bibliotecas:
  http://sic.gob.mx/datos.php?table=otra_bib&estado_id=9
  http://sic.gob.mx/datos.php?table=rnbp&estado_id=9

- Casas de artesanías:
  http://sic.gob.mx/datos.php?table=casa_artesania&estado_id=9

- Centros Culturales:
  http://sic.gob.mx/datos.php?table=centro_cultural&estado_id=9

- Cines:
  http://sic.gob.mx/datos.php?table=comp_cine&estado_id=9

- Galerías:
  http://sic.gob.mx/datos.php?table=galeria&estado_id=9

- Museos:
  http://sic.gob.mx/datos.php?table=museo&estado_id=9

- Teatros:
  http://sic.gob.mx/datos.php?table=teatro&estado_id=9

- Catedrales:
  http://sic.gob.mx/datos.php?table=catedral&estado_id=9

- Fonotecas:
  http://sic.gob.mx/datos.php?table=fonoteca&estado_id=9

- Fototecas:
  http://sic.gob.mx/datos.php?table=fototeca&estado_id=9

- Zonas Arqueológicas:
  http://sic.gob.mx/datos.php?table=zona_arqueologica&estado_id=9

- Códigos Postales:
  https://visdatos.cdmx.gob.mx/app_direct_i/cdmx-shapes/_/session/b20a168f5d50ffcc92b6c2a62de2e03e/download/infoResources2?w=
  https://datos.cdmx.gob.mx/dataset/codigos-postales/resource/8ee17d1b-2d65-4f23-873e-fefc9e418977




